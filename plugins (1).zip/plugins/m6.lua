--[[ 
🌐المطور🌐 @hasammm     
🌐بوت تواصل🌐 @llhasamlllbot    
🌐قناتنا🌐 @Music_hossam
--]] 
do

function run(msg, matches)
return [[

▫️الـبـوت الـذي يـعـمـل عـلـى مـجـمـوعـات الـسـوبـر 

▫️يـعـمـل الـبـوت عـلـى مـجـمـوعـات سـوبـر تـصـل الـى 5 K عـضـو 

   ≪ تـم صـنـع الـبـوت بـواسـطـه الـمـطـور ≫
   
                      『  @hasammm 』
                      
                      
▫️كـل مـا هـو جـديـد عـلـى قـنـاه الـسـورس 
                      
                      [ @Music_hossam ]
                      
▫️للاسـتفـسـار راسـل الـمـطـور :                                     
                     🌐المطور🌐 @hasammm     
                     🌐بوت تواصل🌐 @llhasamlllbot    
                     🌐قناتنا🌐 @Music_hossam
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"^(المطور)$",
},
run = run 
}
end
