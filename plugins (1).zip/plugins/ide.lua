 do

local function hamosh(msg)
if is_momod(msg) then
local reply_id = msg['id']
local idpv = 'ايدي الخاص بيك 🌝❤️ 》'..msg.from.id
send_large_msg('user#id'..msg.from.id, idpv..'\n', ok_cb, false)
local reply = 'راح ادزه خاص😷💡'
reply_msg(reply_id, reply, ok_cb, true)
end
end

return {  
  patterns = {
       "^(ايدي خاص)$",
  },
  run = hamosh,
}

end