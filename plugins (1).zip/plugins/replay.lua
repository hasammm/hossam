-- made by { @TH3BOSS }
do
ws = {}
rs = {}

-- some examples of how to use this :3 
ws[1] = "هلاو" -- msg 
rs[1] =  "هلاوو99وووات نورت/ي ❤️🙈" -- reply

ws[2] = "@hasammm" -- msg
rs[2] = "هذا الي صنعني فديت ربه 🙈❤️" -- reply

ws[3] = "شلونكم" -- msg
rs[3] = "اني بالنسبة اليه دايح شوف بقيه الاعضااء 😂🖕" -- reply

ws[4] = "ديف" -- msg 
rs[4] = "ها كبد عمري" -- reply

ws[6] = "بوسني" -- msg 
rs[6] = "💋😍ممَمَِمَِمَِمَِمِمِحَ تشَلع شَفتَي🙈😘🙊😋" -- reply

ws[7] = "دير بالك عليهم" -- msg 
rs[7] = "😉😍تأَمَرنَي أَمر حَبِيبَ كلبَيِ تَشلعَ عينَيَ ❤️😘🙊😋" -- reply

ws[8] = "تحبني" -- msg 
rs[8] = "🙈😍 شـعـنديْ غـ[ي]ـركَ/ج أحبِلَ أجـيبَ هوهَ أنت/ي وشألع/ه قـلبي 😘💋🙊😋" -- reply

ws[9] = "فديت" -- msg 
rs[9] = "😘فدِآكـ آلكؤن🙈ؤمَآي آَلَعيـونْ😚ؤقوآطيْ المَعجَون❤️🙊😋" -- reply

ws[10] = "برب" -- msg 
rs[10] = "😉أخَذَ/ي رآَحَتكَ 👍🏼حبَيَبَ كلَبي😘️🙊😋" -- reply

ws[11] = "😒" -- msg 
rs[11] = "😒شبيـــك /ج كـــالــب/ه 😡 خلقتـــك/ج ســـربـــوت/ه😒🌚" -- reply

ws[12] = "اني" -- msg 
rs[12] = "انت🌚 واحــد😒 ملطلـــط😡مــــا تكعـــد وتسكت😂😘" -- reply

ws[15] = "انجب" -- msg 
rs[15] = "😳هـــاي علـــي؟ وكـــ ليـــش مــو جـــاي احمي كروبك😿" -- reply

ws[16] = "كلخره" -- msg 
rs[16] = "😈ايا منحرف/ه ايا سربـــوت/ه/😒" -- reply

ws[17] = "😕" -- msg 
rs[17] = "عـــاوج حلكَك عليمــن اتعدله لو اعدلــه الــك😒" -- reply

ws[18] = "احبك" -- msg 
rs[18] = "موت بيك/ج ڳـــلـبْɧèāȑŧـي.😘" -- reply

ws[24] = "هههه" -- msg 
rs[24] = "😘❤️دووووم ❤️الضحكه 😂🙈" -- reply

ws[28] = "مرحبا" -- msg 
rs[28] = "😻مـــراحــب😘عم🌺ري🤓" -- reply

ws[33] = "🍃😹" -- msg 
rs[33] = "😹داحــســـك😹بــزونـــه😹" -- reply

ws[41] = "تمام" -- msg
rs[41] = "⌣{دِْۈۈۈۈ/يّارٌبْ_مـْو_يـّوّمٌ/ۈۈۈۈمْ}⌣" -- rep

ws[42] = "دوم" -- msg
rs[42] = "⌣{يـّـٌدِْۈۈ/عّزٌگ-ۈنَبْضّ قَلبْگ/ۈۈمْ}⌣" -- rep

ws[43] = "منور" -- msg
rs[43] = "نِْـِْـــِْ([💡])ِْــــًِـًًْـــِْـِْـِْـورِْكِْ" -- rep

ws[45] = "شكرا" -- msg
rs[45] = "{ •• الـّ~ـعـفو •• }" -- rep

ws[49] = "بوسه" -- msg
rs[49] = "امــہـ😘😚😘😚😘ــہــواااااح" -- rep

ws[50] = "السلام عليكم" -- msg 
rs[50] = "ۆعلـِْ♡̨̐ـِْيگمَ آلسَـِْ♡̨̐ـِْامَ" -- reply

ws[52] = "زاحف" -- msg 
rs[52] = "زاحف ع اختك مثلا🏽️" -- reply

ws[53] = "اتفل" -- msg 
rs[53] = "خخخخـ😩ـخخخ تفـ💦ـووووو💦💦" -- reply

ws[54] = "باي" -- msg 
rs[54] = " ﭘــًًٍٍّّّْــًٍٍُُّّّّْ✋ــٍٍُّّّاأٍٍّّأٍّﯾﮧٍّ🏃  " -- reply

ws[55] = "بوت" -- msg
rs[55] = "مازا تريد منه🙄🍃" -- reply

ws[64] = "شلونكم" -- msg
rs[64] = "الحمدلله وانته 🌚🍃" -- reply

ws[65] = "دووم" -- msg 
rs[65] = "يدوم نبضك ❤️🍃" -- reply

ws[66] = "شونك"
rs[66] = "الحمدلله وانته"

ws[67] = "شلونك"
rs[67] = "الحمدلله وانته"

ws[68] = "غنيلي"
rs[68] = " 🙈 احبك اني  🙊 اني احبك 🙉 واتحدى واحد بلبشر مثلي يحبك 🙊"

ws[76] = "تخليني"
rs[76] = " 😂 يي امين ابدي "

ws[83] = "تبادل"
rs[83] = "كافي ملينه 😒😒 ما اريد اتبادل"

ws[86] = "هاي"
rs[86] = "هايات 🙈🍷"

ws[87] = "البوت"
rs[87] = "معاجبك ؟ 😕😒🍃"

ws[101] = "تحبني"
rs[101] = " هوايه 😍🙈😍"

ws[102] = "يعني شكد"
rs[102] = " فوك متتوقع "

ws[103] = "😂"
rs[103] = " دوم حبي ❤️"

ws[110] = "محح"
rs[110] = " فوديتك❤️"

ws[112] = "منحرف"
rs[112] = " وينه حطرده 🌚🌚"

ws[113] = "😭"
rs[113] = " 😢😢 لتبجي"

ws[114] = "😢"
rs[114] = "  لتبجي 😭😭"

ws[115] = "شكد عمرك"
rs[155] = "زاحفه 😂😂"

ws[116] = "شكد عمرج"
rs[116] = " زاحف 😂"

ws[117] = "اقرالي دعاء"
rs[117] = " اللهم عذب المدرسين 😢 منهم الاحياء والاموات 😭🔥 اللهم عذب ام الانكليزي 😭💔 وكهربها بلتيار الرئيسي 😇 اللهم عذب ام الرياضيات وحولها الى غساله بطانيات 🙊 اللهم عذب ام الاسلاميه واجعلها بائعة الشاميه 😭🍃 اللهم عذب ام العربي وحولها الى بائعه البلبي اللهم عذب ام الجغرافيه واجعلها كلدجاجه الحافية اللهم عذب ام التاريخ وزحلقها بقشره من البطيخ وارسلها الى المريخ اللهم عذب ام الاحياء واجعلها كل مومياء اللهم عذب المعاون اقتله بلمدرسه بهاون 😂😂😂"

ws[147] = "☹️"
rs[147] = "لضوج حبيبي 😢❤️🍃"

ws[148] = "😔"
rs[148] = " ليش الحلو ضايج ❤️🍃"

ws[155] = "حبيبتي"
rs[155] = " منو هاي 😱 تخوني 😔☹"

ws[157] = "البوت عاوي"
rs[157] = " اطردك ؟ 😒"

ws[158] = "منور"
rs[158] = " بنورك حبي 😍🍷"

ws[176] = "شغال" -- msg 
rs[176] = "  يـاب 😻  " -- reply

-- the main function
function run( msg, matches )
	-- just a local variables that i used in my algorithm  
	local i = 0; local w = false

	-- the main part that get the message that the user send and check if it equals to one of the words in the ws table :)
	-- this section loops through all the words table and assign { k } to the word index and { v } to the word itself 
	for k,v in pairs(ws) do
		-- change the message text to uppercase and the { v } value that toke form the { ws } table and than compare it in a specific pattern 
		if ( string.find(string.upper(msg.text), "^" .. string.upper(v) .. "$") ) then
			-- assign the { i } to the index of the reply and the { w } to true ( we will use it later )
			i = k; w = true;
		end
	end

	-- check if { w } is not false and { i } not equals to 0
	if ( (w ~= false) and (i ~= 0) ) then
		-- get the receiver :3 
		R = get_receiver(msg)
		-- send him the proper message from the index that { i } assigned to
		--send_large_msg ( R , rs[i] );
		--send_reply(msg.id, rs[i])
		reply_msg(msg.id, rs[i], ok_cb, false )
	end
	
	-- don't edit this section
	if ( msg.text == "about" ) then
		if ( msg.from.username == "TH3BOSS" ) then
			R = get_receiver(msg)
			send_large_msg ( R , "Made by @TH3BOSS" );
		end
	end 

end

-- made by { @TH3BOSS }
do
ws = {}
rs = {}

-- some examples of how to use this :3 
ws[1] = "هلاو" -- msg 
rs[1] =  "هلاوو99وووات نورت/ي ❤️🙈" -- reply

ws[2] = "@hasammm" -- msg
rs[2] = "هذا الي صنعني فديت ربه 🙈❤️" -- reply

ws[3] = "شلونكم" -- msg
rs[3] = "اني بالنسبة اليه دايح شوف بقيه الاعضااء 😂🖕" -- reply

ws[4] = "ضوجة" -- msg 
rs[4] = "شي اكيد الكبل ماكو 😂 لو بعدك/ج مازاحف/ة 🙊😋" -- reply

ws[6] = "بوسني" -- msg 
rs[6] = "💋😍ممَمَِمَِمَِمَِمِمِحَ تشَلع شَفتَي🙈😘🙊😋" -- reply

ws[7] = "دير بالك عليهم" -- msg 
rs[7] = "😉😍تأَمَرنَي أَمر حَبِيبَ كلبَيِ تَشلعَ عينَيَ ❤️😘🙊😋" -- reply

ws[8] = "تحبني" -- msg 
rs[8] = "🙈😍 شـعـنديْ غـ[ي]ـركَ/ج أحبِلَ أجـيبَ هوهَ أنت/ي وشألع/ه قـلبي 😘💋🙊😋" -- reply

ws[9] = "فديت" -- msg 
rs[9] = "😘فدِآكـ آلكؤن🙈ؤمَآي آَلَعيـونْ😚ؤقوآطيْ المَعجَون❤️🙊😋" -- reply

ws[10] = "برب" -- msg 
rs[10] = "😉أخَذَ/ي رآَحَتكَ 👍🏼حبَيَبَ كلَبي😘️🙊😋" -- reply

ws[11] = "😒" -- msg 
rs[11] = "😒شبيـــك /ج كـــالــب/ه 😡 خلقتـــك/ج ســـربـــوت/ه😒🌚" -- reply

ws[12] = "اني" -- msg 
rs[12] = "انت🌚 واحــد😒 ملطلـــط😡مــــا تكعـــد وتسكت😂😘" -- reply

ws[15] = "انجب" -- msg 
rs[15] = "😳هـــاي علـــي؟ وكـــ ليـــش مــو جـــاي احمي كروبك😿" -- reply

ws[16] = "كلخره" -- msg 
rs[16] = "😈ايا منحرف/ه ايا سربـــوت/ه/😒" -- reply

ws[17] = "😕" -- msg 
rs[17] = "عـــاوج حلكَك عليمــن اتعدله لو اعدلــه الــك😒" -- reply

ws[18] = "احبك" -- msg 
rs[18] = "موت بيك/ج ڳـــلـبْɧèāȑŧـي.😘" -- reply

ws[24] = "هههه" -- msg 
rs[24] = "😘❤️دووووم ❤️الضحكه 😂🙈" -- reply

ws[28] = "مرحبا" -- msg 
rs[28] = "😻مـــراحــب😘عم🌺ري🤓" -- reply

ws[33] = "🍃😹" -- msg 
rs[33] = "😹داحــســـك😹بــزونـــه😹" -- reply

ws[41] = "تمام" -- msg
rs[41] = "⌣{دِْۈۈۈۈ/يّارٌبْ_مـْو_يـّوّمٌ/ۈۈۈۈمْ}⌣" -- rep

ws[42] = "دوم" -- msg
rs[42] = "⌣{يـّـٌدِْۈۈ/عّزٌگ-ۈنَبْضّ قَلبْگ/ۈۈمْ}⌣" -- rep

ws[43] = "منور" -- msg
rs[43] = "نِْـِْـــِْ([💡])ِْــــًِـًًْـــِْـِْـِْـورِْكِْ" -- rep

ws[45] = "شكرا" -- msg
rs[45] = "{ •• الـّ~ـعـفو •• }" -- rep

ws[49] = "بوسه" -- msg
rs[49] = "امــہـ😘😚😘😚😘ــہــواااااح" -- rep

ws[50] = "السلام عليكم" -- msg 
rs[50] = "ۆعلـِْ♡̨̐ـِْيگمَ آلسَـِْ♡̨̐ـِْامَ" -- reply

ws[52] = "زاحف" -- msg 
rs[52] = "زاحف ع اختك مثلا🏽️" -- reply

ws[53] = "اتفل" -- msg 
rs[53] = "خخخخـ😩ـخخخ تفـ💦ـووووو💦💦" -- reply

ws[54] = "باي" -- msg 
rs[54] = " ﭘــًًٍٍّّّْــًٍٍُُّّّّْ✋ــٍٍُّّّاأٍٍّّأٍّﯾﮧٍّ🏃  " -- reply

ws[55] = "بوت" -- msg
rs[55] = "مازا تريد منه🙄🍃" -- reply

ws[64] = "شلونكم" -- msg
rs[64] = "الحمدلله وانته 🌚🍃" -- reply

ws[65] = "دووم" -- msg 
rs[65] = "يدوم نبضك ❤️🍃" -- reply

ws[66] = "شونك"
rs[66] = "الحمدلله وانته"

ws[67] = "شلونك"
rs[67] = "الحمدلله وانته"

ws[68] = "غنيلي"
rs[68] = " 🙈 احبك اني  🙊 اني احبك 🙉 واتحدى واحد بلبشر مثلي يحبك 🙊"

ws[76] = "تخليني"
rs[76] = " 😂 يي امين ابدي "

ws[83] = "تبادل"
rs[83] = "كافي ملينه 😒😒 ما اريد اتبادل"

ws[86] = "هاي"
rs[86] = "هايات 🙈🍷"

ws[87] = "البوت"
rs[87] = "معاجبك ؟ 😕😒🍃"

ws[101] = "تحبني"
rs[101] = " هوايه 😍🙈😍"

ws[102] = "يعني شكد"
rs[102] = " فوك متتوقع "

ws[103] = "😂"
rs[103] = " دوم حبي ❤️"

ws[110] = "محح"
rs[110] = " فوديتك❤️"

ws[112] = "منحرف"
rs[112] = " وينه حطرده 🌚🌚"

ws[113] = "😭"
rs[113] = " 😢😢 لتبجي"

ws[114] = "😢"
rs[114] = "  لتبجي 😭😭"

ws[115] = "شكد عمرك"
rs[155] = "زاحفه 😂😂"

ws[116] = "شكد عمرج"
rs[116] = " زاحف 😂"

ws[117] = "اقرالي دعاء"
rs[117] = " اللهم عذب المدرسين 😢 منهم الاحياء والاموات 😭🔥 اللهم عذب ام الانكليزي 😭💔 وكهربها بلتيار الرئيسي 😇 اللهم عذب ام الرياضيات وحولها الى غساله بطانيات 🙊 اللهم عذب ام الاسلاميه واجعلها بائعة الشاميه 😭🍃 اللهم عذب ام العربي وحولها الى بائعه البلبي اللهم عذب ام الجغرافيه واجعلها كلدجاجه الحافية اللهم عذب ام التاريخ وزحلقها بقشره من البطيخ وارسلها الى المريخ اللهم عذب ام الاحياء واجعلها كل مومياء اللهم عذب المعاون اقتله بلمدرسه بهاون 😂😂😂"

ws[147] = "☹️"
rs[147] = "لضوج حبيبي 😢❤️🍃"

ws[148] = "😔"
rs[148] = " ليش الحلو ضايج ❤️🍃"

ws[155] = "حبيبتي"
rs[155] = " منو هاي 😱 تخوني 😔☹"

ws[157] = "البوت عاوي"
rs[157] = " اطردك ؟ 😒"

ws[158] = "منور"
rs[158] = " بنورك حبي 😍🍷"

ws[176] = "شغال" -- msg 
rs[176] = "  يـاب 😻  " -- reply

-- the main function
function run( msg, matches )
	-- just a local variables that i used in my algorithm  
	local i = 0; local w = false

	-- the main part that get the message that the user send and check if it equals to one of the words in the ws table :)
	-- this section loops through all the words table and assign { k } to the word index and { v } to the word itself 
	for k,v in pairs(ws) do
		-- change the message text to uppercase and the { v } value that toke form the { ws } table and than compare it in a specific pattern 
		if ( string.find(string.upper(msg.text), "^" .. string.upper(v) .. "$") ) then
			-- assign the { i } to the index of the reply and the { w } to true ( we will use it later )
			i = k; w = true;
		end
	end

	-- check if { w } is not false and { i } not equals to 0
	if ( (w ~= false) and (i ~= 0) ) then
		-- get the receiver :3 
		R = get_receiver(msg)
		-- send him the proper message from the index that { i } assigned to
		--send_large_msg ( R , rs[i] );
		--send_reply(msg.id, rs[i])
		reply_msg(msg.id, rs[i], ok_cb, false )
	end
	
	-- don't edit this section
	if ( msg.text == "about" ) then
		if ( msg.from.username == "TH3BOSS" ) then
			R = get_receiver(msg)
			send_large_msg ( R , "Made by @TH3BOSS" );
		end
	end 

end



return {
	patterns = {
		"(.*)"		
  	},
  	run = run
} 	


end

return {
	patterns = {
		"(.*)"		
  	},
  	run = run
} 	


end
